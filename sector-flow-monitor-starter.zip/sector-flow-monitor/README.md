# Sector Flow Monitor

Eigenständiges Vercel-Projekt mit Twelve-Data-Marktdaten.

1. Repository auf GitHub erstellen und Dateien hochladen.
2. Auf Vercel als neues Projekt importieren (Framework: Other).
3. In Vercel Settings > Environment Variables `TWELVE_DATA_API_KEY` als verschlüsselte Variable für Production hinterlegen.
4. Erneut deployen.

Hinweis: Der kostenlose Twelve-Data-Tarif hat enge Credit-Limits. 14 aufeinanderfolgende API-Abfragen können das Minutenlimit überschreiten. Für produktive Nutzung sollte ein serverseitiger Cache oder eine geplante Aktualisierung ergänzt werden; einzelne Symbole können im Basic-Tarif eingeschränkt sein.
